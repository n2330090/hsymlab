# 2023-Simple-StockData
sample webpage on github

Use Google Colaboratory: Simple StockData scraping from stooq.com - SoftBank 

